module.exports = require("jquery")

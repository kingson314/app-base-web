module.exports = require('mathjs')
